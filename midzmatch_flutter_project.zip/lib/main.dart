import 'package:flutter/material.dart';
import 'screens/signup_screen.dart';
import 'screens/home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MidzmatchApp());
}

class MidzmatchApp extends StatefulWidget {
  const MidzmatchApp({super.key});

  @override
  State<MidzmatchApp> createState() => _MidzmatchAppState();
}

class _MidzmatchAppState extends State<MidzmatchApp> {

  Future<bool> _checkLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('signedUp') ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Midzmatch',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: FutureBuilder(
        future: _checkLoggedIn(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          return snapshot.data! ? const HomeScreen() : const SignupScreen();
        },
      ),
    );
  }
}